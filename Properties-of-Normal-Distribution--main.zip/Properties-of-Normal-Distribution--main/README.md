# Properties-of-Normal-Distribution-
a simple python program
